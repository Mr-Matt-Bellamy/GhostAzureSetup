#Theme Name: Wudan

###Description:
Clean, Flat Style Ghost Theme

###Theme URL:
[http://www.polygonix.com/ghost-themes/wudan-theme-for-ghost/](http://www.polygonix.com/ghost-themes/wudan-theme-for-ghost/)

###Author:
Polygonix

###Author URL:
[http://www.polygonix.com](http://www.polygonix.com)

###Version:
1.0.2

###Installation:

Unzip the theme archive file and upload it to the *content > themes* folder of your Ghost installation.

Alternatively, upload the archive to the same folder and unzip it on the server.

Restart Ghost and you can then select the theme under *Settings > General* in your Ghost installation.

###Notes:

There is a logo in the *assets > images* folder if you would like to use it on your site.